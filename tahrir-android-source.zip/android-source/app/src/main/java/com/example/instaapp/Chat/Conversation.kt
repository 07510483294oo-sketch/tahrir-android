package com.example.instaapp.Chat

class Conversation {
    var uid: String = ""
    var username: String = ""
    var fullname: String = ""
    var image: String = ""
    var lastMessage: String = ""
    var timestamp: Long = 0L
    var unread: Long = 0L
    constructor()
}
