package com.example.instaapp.Chat

object ChatUtils {
    fun chatId(a: String, b: String): String = if (a < b) "${a}_$b" else "${b}_$a"
}
