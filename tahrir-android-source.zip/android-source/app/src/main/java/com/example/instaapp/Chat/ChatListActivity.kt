package com.example.instaapp.Chat

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.instaapp.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_chat_list.*

class ChatListActivity : AppCompatActivity() {
    private val items = ArrayList<Conversation>()
    private lateinit var adapter: ConversationAdapter
    private lateinit var ref: DatabaseReference
    private var listener: ValueEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_list)
        setSupportActionBar(chat_list_toolbar)
        supportActionBar?.title = "Messages"
        chat_list_back.setOnClickListener { finish() }
        adapter = ConversationAdapter(this, items)
        conversations_recycler.layoutManager = LinearLayoutManager(this)
        conversations_recycler.adapter = adapter
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        ref = FirebaseDatabase.getInstance().reference.child("Conversations").child(uid)
        listener = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                items.clear()
                for (child in s.children) {
                    val c = child.getValue(Conversation::class.java) ?: continue
                    items.add(c)
                }
                items.sortByDescending { it.timestamp }
                adapter.notifyDataSetChanged()
                empty_conversations.visibility = if (items.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        ref.addValueEventListener(listener!!)
    }
    override fun onDestroy() {
        if (::ref.isInitialized && listener != null) ref.removeEventListener(listener!!)
        super.onDestroy()
    }
}
