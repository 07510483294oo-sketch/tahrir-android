package com.example.instaapp.Chat

class ChatMessage {
    var id: String = ""
    var senderId: String = ""
    var receiverId: String = ""
    var text: String = ""
    var imageUrl: String = ""
    var timestamp: Long = 0L
    var seen: Boolean = false
    var replyTo: String = ""

    constructor()
}
