package com.example.instaapp.core

object AppConfig {
    const val PREFS = "INSTA_APP"
    const val PROFILE_ID = "profileId"
    const val FIRST_RUN = "firstRun"
    const val NETWORK_TIMEOUT_MESSAGE = "تحقق من اتصال الإنترنت ثم حاول مرة أخرى"
}
