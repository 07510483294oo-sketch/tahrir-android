package com.example.instaapp.core

import android.content.Context
import com.google.firebase.auth.FirebaseAuth

class SessionManager(context: Context) {
    private val prefs = context.getSharedPreferences(AppConfig.PREFS, Context.MODE_PRIVATE)

    fun isLoggedIn(): Boolean = FirebaseAuth.getInstance().currentUser != null

    fun userId(): String? = FirebaseAuth.getInstance().currentUser?.uid

    fun setProfileId(id: String?) {
        prefs.edit().putString(AppConfig.PROFILE_ID, id).apply()
    }

    fun profileId(): String? = prefs.getString(AppConfig.PROFILE_ID, null)

    fun clear() {
        prefs.edit().clear().apply()
    }
}
