package com.example.instaapp.Chat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.instaapp.R
import com.google.firebase.auth.FirebaseAuth
import com.squareup.picasso.Picasso

class MessageAdapter(private val items: MutableList<ChatMessage>) : RecyclerView.Adapter<MessageAdapter.Holder>() {
    private val me = FirebaseAuth.getInstance().currentUser?.uid.orEmpty()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.chat_message_item, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val m = items[position]
        val mine = m.senderId == me
        holder.left.visibility = if (mine) View.GONE else View.VISIBLE
        holder.right.visibility = if (mine) View.VISIBLE else View.GONE
        val text = if (m.imageUrl.isNotEmpty()) "[Image]" else m.text
        if (mine) {
            holder.rightText.text = text
            holder.rightSeen.text = if (m.seen) "Seen" else "Sent"
            if (m.imageUrl.isNotEmpty()) { holder.rightImage.visibility = View.VISIBLE; holder.rightText.visibility = View.GONE; Picasso.get().load(m.imageUrl).into(holder.rightImage) } else { holder.rightImage.visibility = View.GONE; holder.rightText.visibility = View.VISIBLE }
        } else {
            holder.leftText.text = text
            if (m.imageUrl.isNotEmpty()) { holder.leftImage.visibility = View.VISIBLE; holder.leftText.visibility = View.GONE; Picasso.get().load(m.imageUrl).into(holder.leftImage) } else { holder.leftImage.visibility = View.GONE; holder.leftText.visibility = View.VISIBLE }
        }
    }

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val left: View = v.findViewById(R.id.message_left)
        val right: View = v.findViewById(R.id.message_right)
        val leftText: TextView = v.findViewById(R.id.message_left_text)
        val rightText: TextView = v.findViewById(R.id.message_right_text)
        val rightSeen: TextView = v.findViewById(R.id.message_right_seen)
        val leftImage: ImageView = v.findViewById(R.id.message_left_image)
        val rightImage: ImageView = v.findViewById(R.id.message_right_image)
    }
}
