package com.example.instaapp.core

import android.view.View

object UiGuard {
    fun clickOnce(view: View, cooldownMs: Long = 700L, action: () -> Unit) {
        if (!view.isEnabled) return
        view.isEnabled = false
        try {
            action()
        } finally {
            view.postDelayed({ view.isEnabled = true }, cooldownMs)
        }
    }
}
