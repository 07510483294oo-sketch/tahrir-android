package com.example.instaapp.Chat

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.instaapp.R
import com.squareup.picasso.Picasso
import de.hdodenhof.circleimageview.CircleImageView

class ConversationAdapter(private val context: Context, private val items: MutableList<Conversation>) : RecyclerView.Adapter<ConversationAdapter.Holder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder = Holder(LayoutInflater.from(context).inflate(R.layout.conversation_item, parent, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val c = items[position]
        holder.username.text = c.username
        holder.fullname.text = c.fullname
        holder.last.text = c.lastMessage
        Picasso.get().load(c.image).placeholder(R.drawable.profile).into(holder.image)
        holder.itemView.setOnClickListener {
            context.startActivity(Intent(context, ChatActivity::class.java).apply {
                putExtra("uid", c.uid)
                putExtra("username", c.username)
                putExtra("image", c.image)
            })
        }
    }
    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val image: CircleImageView = v.findViewById(R.id.conversation_image)
        val username: TextView = v.findViewById(R.id.conversation_username)
        val fullname: TextView = v.findViewById(R.id.conversation_fullname)
        val last: TextView = v.findViewById(R.id.conversation_last)
    }
}
