package com.example.instaapp.Chat

import android.app.ProgressDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.instaapp.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_chat.*

class ChatActivity : AppCompatActivity() {
    private val messages = ArrayList<ChatMessage>()
    private lateinit var adapter: MessageAdapter
    private lateinit var messagesRef: DatabaseReference
    private lateinit var chatId: String
    private lateinit var me: String
    private lateinit var other: String
    private var messageListener: ChildEventListener? = null
    private var imageUri: Uri? = null
    private var myUsername = "User"
    private var myFullname = "User"
    private var myImage = ""
    private val pickImage = 801

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        me = FirebaseAuth.getInstance().currentUser?.uid ?: run { finish(); return }
        other = intent.getStringExtra("uid") ?: run { finish(); return }
        chatId = ChatUtils.chatId(me, other)
        chat_username.text = intent.getStringExtra("username") ?: "User"
        Picasso.get().load(intent.getStringExtra("image")).placeholder(R.drawable.profile).into(chat_image)
        chat_back.setOnClickListener { finish() }
        adapter = MessageAdapter(messages)
        chat_recycler.layoutManager = LinearLayoutManager(this)
        chat_recycler.adapter = adapter
        chat_recycler.itemAnimator = null
        messagesRef = FirebaseDatabase.getInstance().reference.child("Chats").child(chatId).child("messages")
        loadMyProfile()
        listenMessages()
        markSeen()
        listenTyping()
        listenPresence()
        send_message.setOnClickListener { sendText() }
        attach_image.setOnClickListener { pickImage() }
        chat_input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateTyping(s?.isNotEmpty() == true) }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun loadMyProfile() {
        FirebaseDatabase.getInstance().reference.child("Users").child(me)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) {
                    myUsername = s.child("username").getValue(String::class.java) ?: "User"
                    myFullname = s.child("fullname").getValue(String::class.java) ?: myUsername
                    myImage = s.child("image").getValue(String::class.java) ?: ""
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun listenMessages() {
        messageListener = object : ChildEventListener {
            override fun onChildAdded(s: DataSnapshot, previousChildName: String?) {
                val m = s.getValue(ChatMessage::class.java) ?: return
                if (m.id.isEmpty()) m.id = s.key.orEmpty()
                messages.add(m)
                adapter.notifyItemInserted(messages.lastIndex)
                chat_recycler.scrollToPosition(messages.lastIndex)
                if (m.receiverId == me && !m.seen) {
                    s.ref.child("seen").setValue(true)
                }
            }
            override fun onChildChanged(s: DataSnapshot, previousChildName: String?) {
                val index = messages.indexOfFirst { it.id == s.key }
                if (index >= 0) { messages[index] = s.getValue(ChatMessage::class.java) ?: messages[index]; adapter.notifyItemChanged(index) }
            }
            override fun onChildRemoved(s: DataSnapshot) {}
            override fun onChildMoved(s: DataSnapshot, previousChildName: String?) {}
            override fun onCancelled(error: DatabaseError) {}
        }
        messagesRef.addChildEventListener(messageListener!!)
    }

    private fun sendText() {
        val text = chat_input.text.toString().trim()
        if (text.isEmpty()) return
        sendMessage(text, "")
        chat_input.text.clear()
    }

    private fun sendMessage(text: String, image: String) {
        val key = messagesRef.push().key ?: return
        val now = System.currentTimeMillis()
        val map = hashMapOf<String, Any>(
            "id" to key, "senderId" to me, "receiverId" to other, "text" to text,
            "imageUrl" to image, "timestamp" to now, "seen" to false
        )
        val updates = hashMapOf<String, Any>(
            "Chats/$chatId/messages/$key" to map,
            "Conversations/$me/$other/uid" to other,
            "Conversations/$me/$other/username" to (intent.getStringExtra("username") ?: "User"),
            "Conversations/$me/$other/image" to (intent.getStringExtra("image") ?: ""),
            "Conversations/$me/$other/lastMessage" to if (image.isNotEmpty()) "Image" else text,
            "Conversations/$me/$other/timestamp" to now,
            "Conversations/$me/$other/unread" to 0,
            "Conversations/$other/$me/uid" to me,
            "Conversations/$other/$me/lastMessage" to if (image.isNotEmpty()) "Image" else text,
            "Conversations/$other/$me/timestamp" to now
        )
        val root = FirebaseDatabase.getInstance().reference
        root.updateChildren(updates).addOnSuccessListener {
            root.child("Conversations").child(other).child(me).child("username").setValue(myUsername)
            root.child("Conversations").child(other).child(me).child("fullname").setValue(myFullname)
            root.child("Conversations").child(other).child(me).child("image").setValue(myImage)
            root.child("Conversations").child(other).child(me).child("unread").runTransaction(object : Transaction.Handler {
                override fun doTransaction(currentData: MutableData): Transaction.Result {
                    val n = currentData.getValue(Long::class.java) ?: 0L
                    currentData.value = n + 1L
                    return Transaction.success(currentData)
                }
                override fun onComplete(error: DatabaseError?, committed: Boolean, currentData: DataSnapshot?) {}
            })
        }
    }

    private fun pickImage() { startActivityForResult(Intent(Intent.ACTION_PICK).apply { type = "image/*" }, pickImage) }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickImage || resultCode != RESULT_OK) return
        imageUri = data?.data ?: return
        val dialog = ProgressDialog(this)
        dialog.setMessage("Sending image...")
        dialog.setCancelable(false)
        dialog.show()
        val key = messagesRef.push().key ?: return
        FirebaseStorage.getInstance().reference.child("Chat Images").child(chatId).child("$key.jpg").putFile(imageUri!!)
            .continueWithTask { task -> if (!task.isSuccessful) throw (task.exception ?: Exception("Upload failed")); task.result.storage.downloadUrl }
            .addOnSuccessListener { url ->
                val now = System.currentTimeMillis()
                val map = hashMapOf<String, Any>("id" to key, "senderId" to me, "receiverId" to other, "text" to "", "imageUrl" to url.toString(), "timestamp" to now, "seen" to false)
                val updates = hashMapOf<String, Any>(
                    "Chats/$chatId/messages/$key" to map,
                    "Conversations/$me/$other/uid" to other,
                    "Conversations/$me/$other/username" to (intent.getStringExtra("username") ?: "User"),
                    "Conversations/$me/$other/image" to (intent.getStringExtra("image") ?: ""),
                    "Conversations/$me/$other/lastMessage" to "Image",
                    "Conversations/$me/$other/timestamp" to now,
                    "Conversations/$other/$me/uid" to me,
                    "Conversations/$other/$me/lastMessage" to "Image",
                    "Conversations/$other/$me/timestamp" to now
                )
                val root = FirebaseDatabase.getInstance().reference
                root.updateChildren(updates).addOnSuccessListener {
                    root.child("Conversations").child(other).child(me).child("username").setValue(myUsername)
                    root.child("Conversations").child(other).child(me).child("fullname").setValue(myFullname)
                    root.child("Conversations").child(other).child(me).child("image").setValue(myImage)
                    root.child("Conversations").child(other).child(me).child("unread").runTransaction(object : Transaction.Handler {
                        override fun doTransaction(currentData: MutableData): Transaction.Result {
                            val n = currentData.getValue(Long::class.java) ?: 0L
                            currentData.value = n + 1L
                            return Transaction.success(currentData)
                        }
                        override fun onComplete(error: DatabaseError?, committed: Boolean, currentData: DataSnapshot?) {}
                    })
                    dialog.dismiss()
                }.addOnFailureListener { dialog.dismiss(); Toast.makeText(this, it.message ?: "Send failed", Toast.LENGTH_LONG).show() }
            }.addOnFailureListener { dialog.dismiss(); Toast.makeText(this, it.message ?: "Upload failed", Toast.LENGTH_LONG).show() }
    }

    private fun listenTyping() {
        FirebaseDatabase.getInstance().reference.child("Typing").child(chatId).child(other)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) {
                    chat_status.text = if (s.getValue(Boolean::class.java) == true) "typing..." else ""
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun markSeen() {
        messagesRef.orderByChild("receiverId").equalTo(me).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) { for (c in s.children) if (c.child("seen").getValue(Boolean::class.java) != true) c.ref.child("seen").setValue(true) }
            override fun onCancelled(error: DatabaseError) {}
        })
        FirebaseDatabase.getInstance().reference.child("Conversations").child(me).child(other).child("unread").setValue(0)
    }

    private fun listenPresence() {
        FirebaseDatabase.getInstance().reference.child("Presence").child(other)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(s: DataSnapshot) {
                    if (chat_status.text.toString() != "typing...") {
                        chat_status.text = if (s.getValue(Boolean::class.java) == true) "Online" else "Offline"
                    }
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    private fun updateTyping(typing: Boolean) {
        FirebaseDatabase.getInstance().reference.child("Typing").child(chatId).child(me).setValue(typing)
    }

    override fun onStop() {
        updateTyping(false)
        super.onStop()
    }
    override fun onDestroy() {
        if (::messagesRef.isInitialized && messageListener != null) messagesRef.removeEventListener(messageListener!!)
        updateTyping(false)
        super.onDestroy()
    }
}
