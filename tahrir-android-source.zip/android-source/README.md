# Tahrir Android Source

Tahrir is a global social space inspired by modern messaging and visual social
feeds. The Arabic identity **تحرير المصلاوي** remains part of the brand story.

## Build later

Open this folder in Android Studio, allow Gradle to download the declared
dependencies, and build a debug or release variant when ready. This source
delivery intentionally contains no generated APK or AAB.

## Firebase compatibility

The existing application id `com.example.instaapp` is preserved because the
Firebase configuration and database rules are tied to it. The user-facing name
is now Tahrir. Changing the application id requires a new Firebase Android app
and a replacement `google-services.json`.

## Telegram delivery

The optional helper reads `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` from the
environment. No bot token is stored in source.

نسخة Android مطورة من المشروع الأصلي، مع تحديث سلسلة البناء وإضافة طبقة Core لإدارة الجلسة، الشبكة ومنع الضغط المتكرر.

## البناء
- Gradle 7.6.1
- Android Gradle Plugin 7.4.2
- Kotlin 1.7.22
- compileSdk 33
- targetSdk 33
- minSdk 21

الأوامر:
`./gradlew assembleDebug`

الـAPK الناتج:
`app/build/outputs/apk/debug/app-debug.apk`
