#!/usr/bin/env bash
set -euo pipefail

: "${TELEGRAM_BOT_TOKEN:?Set TELEGRAM_BOT_TOKEN in the environment}"
: "${TELEGRAM_CHAT_ID:?Set TELEGRAM_CHAT_ID in the environment}"

SOURCE_ZIP="${1:-tahrir-android-source.zip}"
if [[ ! -f "$SOURCE_ZIP" ]]; then
  echo "Source archive not found: $SOURCE_ZIP" >&2
  exit 1
fi

curl --fail-with-body --silent --show-error \
  -F "chat_id=${TELEGRAM_CHAT_ID}" \
  -F "document=@${SOURCE_ZIP};type=application/zip" \
  "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendDocument" \
  >/dev/null

echo "Source archive sent successfully."