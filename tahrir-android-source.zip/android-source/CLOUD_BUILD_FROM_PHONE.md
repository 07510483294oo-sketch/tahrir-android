# بناء APK من الهاتف عبر GitHub Actions

هذا المشروع مجهز ليتم بناؤه سحابيًا بدون كمبيوتر محلي.

1. ارفع ملفات المشروع إلى مستودع GitHub.
2. افتح تبويب Actions.
3. اختر **Build Android APK**.
4. اضغط **Run workflow** أو ادفع Commit إلى فرع `main`.
5. بعد نجاح البناء، افتح نتيجة التشغيل ثم قسم **Artifacts** وحمّل `InstaApp-debug-apk`.

ملاحظات:
- ملف `google-services.json` موجود داخل `app/` ويجب أن يكون تابعًا لمشروع Firebase الذي تملكه.
- هذا workflow يبني نسخة Debug للتجربة.
- لا يطلب أي متغيرات سرية جديدة.
